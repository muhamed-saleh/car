﻿namespace PLProj
{
    public class StripeSettings
    {
        public string secretJey { get; set; }
        public string publishablekey { get; set; }
    }
}
